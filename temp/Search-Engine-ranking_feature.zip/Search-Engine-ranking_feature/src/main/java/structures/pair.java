package structures;

public class pair<T,Y>{

    public T first;
    public Y second;

    public pair()
    {}

    public pair(T first,Y second)
    {
        this.first=first;
        this.second=second;
    }
}