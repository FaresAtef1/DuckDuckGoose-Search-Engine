# Search-Engine
The aim of this project is to develop a simple Crawler- based search engine that demonstrates the main
features of a search engine (web crawling, indexing and ranking) and the interaction between them.

# ⚡Technologies
![Java](https://img.shields.io/badge/java-%23ED8B00.svg?style=for-the-badge&logo=java&logoColor=white)
![MongoDB](https://img.shields.io/badge/MongoDB-%234ea94b.svg?style=for-the-badge&logo=mongodb&logoColor=white)

# 📌Prerequisites
